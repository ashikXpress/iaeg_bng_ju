<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CategoryGallery extends Model
{

    protected $table='category_gallery';
    protected $guarded=[];
}
