<!-- Favicon -->
<link rel="shortcut icon" href="<?php echo e(asset('assets/admin/images/favicon.ico')); ?>" />
<!-- Bootstrap CSS -->
<link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/bootstrap.min.css')); ?>">
<!-- Typography CSS -->
<link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/typography.css')); ?>">
<!-- Style CSS -->
<link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/style.css')); ?>">
<!-- Responsive CSS -->
<link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/responsive.css')); ?>">
<!-- Full calendar -->
<link href="<?php echo e(asset('assets/admin/fullcalendar/core/main.css')); ?>" rel='stylesheet' />
<link href="<?php echo e(asset('assets/admin/fullcalendar/daygrid/main.css')); ?>" rel='stylesheet' />
<link href="<?php echo e(asset('assets/admin/fullcalendar/timegrid/main.css')); ?>" rel='stylesheet' />
<link href="<?php echo e(asset('assets/admin/fullcalendar/list/main.css')); ?>" rel='stylesheet' />

<link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/flatpickr.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/admin/sweetalert/sweetalert.css')); ?>">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

<style>
    .active{
        color:#089eae !important;
    }
</style>
<?php /**PATH D:\PHP-7.4.2\htdocs\ju\resources\views/layouts/assets/__style.blade.php ENDPATH**/ ?>