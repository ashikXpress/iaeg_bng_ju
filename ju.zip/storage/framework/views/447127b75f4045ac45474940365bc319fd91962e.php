<?php $__env->startSection('additionalCSS'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/lightbox2/css/lightbox.min.css')); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- Start Breadcrumbs -->
    <section class="breadcrumbs overlay">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h2><?php echo e($gallery_category->name); ?> </h2>
                    <ul class="bread-list">
                        <li><a href="<?php echo e(route('home')); ?>">Home<i class="fa fa-angle-right"></i></a></li>
                        <li class="active"><a href="#"><?php echo e($gallery_category->name); ?></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!--/ End Breadcrumbs -->

    <!-- Features -->
    <section class="our-features section ">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-title">
                        <h2>Your <span> Photo</span> Gallery</h2>

                    </div>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-4 col-12">
                    <!-- Single Feature -->
                    <a href="<?php echo e(asset($gallery->image)); ?>" data-lightbox="album" data-title="<?php echo e($gallery->title); ?>" data-alt="not">
                    <div class="single-feature">
                        <div class="feature-head">
                            <img src="<?php echo e(asset($gallery->image)); ?>" alt="#">
                        </div>

                    </div>
                    <!--/ End Single Feature -->
                </a>

            </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        </div>

    </section>
    <!-- End Features -->

<div class="container">
    <div class="row">
        <div class="col-12 text-center">

            <!-- Start Pagination -->
            <div class="pagination-main">
                <?php echo e($galleries->links()); ?>

            </div>
            <!--/ End Pagination -->
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('additionalJS'); ?>
    <script src="<?php echo e(asset('assets/frontend/lightbox2/js/lightbox.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHP-7.4.2\htdocs\ju\resources\views/frontend/gallery.blade.php ENDPATH**/ ?>