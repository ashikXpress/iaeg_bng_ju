<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col-md-12">
            <div class="iq-card">
                <div class="iq-card-header d-flex justify-content-between">
                    <div class="iq-header-title">
                        <div class="card-title">
                            <div class="pull-left">
                                <h4>All Event</h4>
                            </div>
                            <div class="pull-right">

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-create')): ?>

                                    <a class="btn btn-primary" href="<?php echo e(route('event.form')); ?>"> Create New Event</a>

                                <?php endif; ?>

                            </div>
                        </div>

                    </div>
                </div>
                <div class="iq-card-body">
                    <?php if($message = Session::get('success')): ?>

                        <div class="alert alert-success">

                            <p><?php echo e($message); ?></p>

                        </div>

                    <?php endif; ?>
                    <table class="table">
                        <thead>
                        <tr>

                            <th>No</th>
                            <th>Name</th>
                            <th>Venue</th>
                            <th>Session</th>
                            <th>Start to End</th>
                            <th>Event Category</th>
                            <th width="280px">Action</th>

                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>

                                <td><?php echo e($loop->iteration); ?></td>

                                <td><?php echo e($event->name); ?></td>
                                <td><?php echo e($event->venue); ?></td>
                                <td><?php echo e($event->session); ?></td>
                                <td width="180px"><?php echo e(date('d M y, h:m A',strtotime($event->start_date)) .' to '.date('d M y, h:m A',strtotime($event->end_date))); ?></td>
                                <td><?php echo e($event->categoryName->name); ?></td>
                                <td>
                                    <a class="btn btn-info" href="<?php echo e(route('event.edit', $event->id)); ?>">Edit</a>

                                    <a href="#" onclick="return checkDelete('<?php echo e(route('event.delete',$event->id)); ?>;')" class="btn btn-danger">Delete</a>

                                </td>

                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>

                    <?php echo e($events->links()); ?>

                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHP-7.4.2\htdocs\ju\resources\views/admin/event/all.blade.php ENDPATH**/ ?>