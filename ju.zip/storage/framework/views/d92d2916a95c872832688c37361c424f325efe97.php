<?php $__env->startSection('content'); ?>
    <!-- Start Breadcrumbs -->
    <section class="breadcrumbs overlay">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h2><?php echo e($event_name->name); ?></h2>
                    <ul class="bread-list">
                        <li><a href="<?php echo e(route('home')); ?>">Home<i class="fa fa-angle-right"></i></a></li>
                        <li class="active"><a href="#"><?php echo e($event_name->name); ?></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!--/ End Breadcrumbs -->

    <!-- Events -->
    <section class="events archives section">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-title">
                        <h2>Upcoming <span>Events</span></h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 col-12">
                    <!-- Single Event -->
                    <div class="single-event">
                        <div class="head overlay">
                            <img src="<?php echo e(asset($event->images[0]->image)); ?>" alt="#">
                            <a href="<?php echo e(route('event.details',$event->id)); ?>" class="btn"><i class="fa fa-link"></i></a>
                        </div>
                        <div class="event-content">
                            <div class="meta">
                                <div class=""><strong>Start Date</strong></div>
                                <span><i class="fa fa-calendar"></i><?php echo e(date('d M Y',strtotime($event->start_date))); ?></span>
                                <span><i class="fa fa-clock-o"></i><?php echo e(date('h:m A',strtotime($event->start_date))); ?></span>
                            </div>

                            <div class="meta">
                                <div class=""><strong>End Date</strong></div>
                                <span><i class="fa fa-calendar"></i><?php echo e(date('d M Y',strtotime($event->start_date))); ?></span>
                                <span><i class="fa fa-clock-o"></i><?php echo e(date('h:m A',strtotime($event->start_date))); ?></span>
                            </div>
                            <h4><a href="<?php echo e(route('event.details',$event->id)); ?>"><?php echo e($event->name); ?></a></h4>
                            <p><?php echo e(\Illuminate\Support\Str::limit($event->description, 100, $end='...')); ?></p>
                            <div class="button">
                                <a href="<?php echo e(route('event.details',$event->id)); ?>" class="btn">Read More</a>
                            </div>
                        </div>
                    </div>
                    <!--/ End Single Event -->
                </div>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="row">
                <div class="col-12">
                    <!-- Start Pagination -->
                    <div class="pagination-main">
                        <?php echo e($events->links()); ?>

                    </div>
                    <!--/ End Pagination -->
                </div>
            </div>
        </div>
    </section>
    <!--/ End Events -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHP-7.4.2\htdocs\ju\resources\views/frontend/event.blade.php ENDPATH**/ ?>