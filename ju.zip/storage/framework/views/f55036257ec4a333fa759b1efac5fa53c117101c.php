<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php echo $__env->make('layouts.assets.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="row">
        <div class="col-md-12">
            <?php if(Auth::guard('member')->user()->is_member==1): ?>
                <span class="alert alert-success text-center" style="font-size:20px;display: block"><a style="color:#089cac" href="<?php echo e(route('member.technical.event')); ?>">You are a <strong><?php echo e(Auth::guard('member')->user()->memberType->name); ?></strong> of IEAG_BNG, so you have discount for every event participating </a></span>
            <?php endif; ?>
        </div>
    </div>

    <div class="row"  style="min-height: 450px">
        <div class="col-lg-12">
            <div class="row">
                <a href="<?php echo e(route('member.technical.event')); ?>" class="col-md-3 col-lg-3">
                    <div class="iq-card">
                        <div class="iq-card-body iq-bg-primary rounded">
                            <div class="d-flex align-items-center justify-content-between">
                                <div class="rounded-circle iq-card-icon bg-primary"><i class="ri-user-fill"></i></div>
                                <div class="text-right">
                                    <h2 class="mb-0"><span class="counter"><?php echo e($technical); ?></span></h2>
                                    <h5 class="">Technical Event</h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
                <a href="<?php echo e(route('member.exhibition.event')); ?>" class="col-md-3 col-lg-3">
                    <div class="iq-card">
                        <div class="iq-card-body iq-bg-warning rounded">
                            <div class="d-flex align-items-center justify-content-between">
                                <div class="rounded-circle iq-card-icon bg-warning"><i class="ri-user-fill"></i></div>
                                <div class="text-right">
                                    <h2 class="mb-0"><span class="counter"><?php echo e($exhibition); ?></span></h2>
                                    <h5 class="">Exhibition Event</h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
                <a href="<?php echo e(route('member.exhibition.event')); ?>" class="col-md-3 col-lg-3">
                    <div class="iq-card">
                        <div class="iq-card-body iq-bg-danger rounded">
                            <div class="d-flex align-items-center justify-content-between">
                                <div class="rounded-circle iq-card-icon bg-danger"><i class="ri-user-fill"></i></div>
                                <div class="text-right">
                                    <h2 class="mb-0"><span class="counter"><?php echo e($field); ?></span></h2>
                                    <h5 class="">Field Event</h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHP-7.4.2\htdocs\ju\resources\views/member/dashboard.blade.php ENDPATH**/ ?>