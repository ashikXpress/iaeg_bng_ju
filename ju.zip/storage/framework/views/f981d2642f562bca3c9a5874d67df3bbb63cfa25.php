<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="iq-card">
                <div class="iq-card-header d-flex justify-content-between">
                    <div class="iq-header-title">
                        <h4 class="card-title">Role Management
                            <div class="pull-right">

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-create')): ?>

                                    <a class="btn btn-success" href="<?php echo e(route('roles.create')); ?>"> Create New Role</a>

                                <?php endif; ?>

                            </div>
                        </h4>

                    </div>
                </div>
                <div class="iq-card-body">
                    <?php if($message = Session::get('success')): ?>

                        <div class="alert alert-success">

                            <p><?php echo e($message); ?></p>

                        </div>

                    <?php endif; ?>
                    <table class="table">
                        <thead>
                        <tr>
                            <th scope="col">No</th>
                            <th scope="col">Name</th>
                            <th scope="col">action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td scope="row"><?php echo e(++$i); ?></td>

                                <td><?php echo e($role->name); ?></td>

                                <td>

                                    <a class="btn btn-info" href="<?php echo e(route('roles.show',$role->id)); ?>">Show</a>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-edit')): ?>

                                        <a class="btn btn-primary" href="<?php echo e(route('roles.edit',$role->id)); ?>">Edit</a>

                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-delete')): ?>

                                        <?php echo Form::open(['method' => 'DELETE','route' => ['roles.destroy', $role->id],'style'=>'display:inline']); ?>


                                        <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>


                                        <?php echo Form::close(); ?>


                                    <?php endif; ?>

                                </td>

                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                    <?php echo $roles->render(); ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHP-7.4.2\htdocs\ju\resources\views/roles/index.blade.php ENDPATH**/ ?>