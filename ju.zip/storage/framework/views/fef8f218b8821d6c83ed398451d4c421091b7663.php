<?php $__env->startSection('additionalCSS'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/lightbox2/css/lightbox.min.css')); ?>">

    <style>
        .home-slider .single-slider:before {
            opacity: 0.3;
        }
        a.btn-about {
            display: inline-block;
            background: #00b16a;
            color: #fff;
            padding: 11px 18px;
            border-bottom: 5px;
            margin: 8px 0px;
            text-transform: uppercase;
            font-weight: bold;
            font-size: 17px;
            border: 1px solid #00b16a;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- Slider Area -->
    <section class="home-slider">
        <div class="slider-active">

            <!-- Single Slider -->
            <?php $__currentLoopData = $sliders->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="single-slider overlay" style="background-image:url('<?php echo e(asset($slider->image)); ?>')">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8
                         <?php if($loop->iteration == 1): ?>
                            col-md-8 col-12
                            <?php elseif($loop->iteration == 2): ?>
                            offset-lg-2 col-md-8 offset-md-2 col-12
                            <?php else: ?>
                            offset-lg-4 col-md-8 offset-md-4 col-12
                            <?php endif; ?>

                            ">
                            <div class="slider-text
                                <?php if($loop->iteration == 1): ?>

                                <?php elseif($loop->iteration == 2): ?>
                                    text-center
                                <?php else: ?>
                                    text-right
                                <?php endif; ?>
                                ">
                                <h1><?php echo e($slider->title); ?></h1>
                                <p><?php echo e($slider->sub_title); ?></p>
                                <div class="button">
                                    <a href="<?php echo e(route('about')); ?>" class="btn primary">About Us</a>
                                    <a href="<?php echo e(route('contact')); ?>" class="btn">Contact Us</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!--/ End Single Slider -->

        </div>
    </section>
    <!--/ End Slider Area -->

    <!-- Features -->
    <section class="our-features section">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-title">
                        <h2>About<span> Us</span></h2>

                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6 col-md-6 col-12">
                    <!-- Single Feature -->
                    <div class="single-feature">
                        <div class="feature-head">
                            <img src="<?php echo e(asset('assets/frontend/images/feature1.jpg')); ?>" alt="#">
                        </div>
                    </div>
                    <!--/ End Single Feature -->
                </div>
                <div class="col-lg-6 col-md-6 col-12">
                    <!-- Single Feature -->
                    <div class="single-feature">
                        <h2>Student Admin Panel</h2>
                        <p>As marketing professionals in the experiential world, we have become accusto to the idea of an ever evolving industry. Brands today are moving away from purely face to face physical experiences, and bringing their essence to life, not only through digital immersion creativity but through new technology as well including Virtual Reality.

                            face physical experiences, and bringing their essence to life, not only through digital immersion creativity but through new technology as well including Virtual Reality As marketing professionals in the experiential world, we have become accusto to the idea of an ever evolving industry. Brands today are moving away from purely face to face physical experiences,</p>
                        <div class="button">
                            <a href="<?php echo e(route('about')); ?>" class="btn-about">Read More</a>
                        </div>
                    </div>
                    <!--/ End Single Feature -->
                </div>

            </div>
        </div>
    </section>
    <!-- End Features -->

    <!-- Enroll -->
    <section class="enroll overlay section" data-stellar-background-ratio="0.5">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 offset-lg-1">
                    <div class="row">
                        <div class="col-lg-6 col-12">
                            <!-- Single Enroll -->
                            <div class="enroll-form">
                                <div class="form-title">
                                    <h2>Enroll Membership</h2>
                                    <p>And get discount for events joining !!</p>
                                </div>
                                <!-- Form -->
                                <form class="form" action="#">
                                    <div class="form-group button">
                                        <a href="<?php echo e(route('member.register.form')); ?>" type="submit" class="btn">Register Now</a>
                                    </div>
                                </form>
                                <!--/ End Form -->
                            </div>
                            <!-- Single Enroll -->
                        </div>
                        <div class="col-lg-6 col-12">
                            <div class="enroll-right">
                                <div class="section-title">
                                    <h2>We Have More Events, You Can Join First !!</h2>
                                </div>
                            </div>
                            <!-- Skill Main -->
                            <div class="skill-main">
                                <div class="row">
                                    <div class="col-lg-4 col-md-4 col-12 wow zoomIn" data-wow-delay="0.8s">
                                        <!-- Single Skill -->
                                        <div class="single-skill">
                                            <div class="circle" data-value="0.<?php echo e($technical_event_count); ?>" data-size="130">
                                                <strong><?php echo e($technical_event_count); ?> +</strong>
                                            </div>
                                            <h4>Technical Event</h4>
                                        </div>
                                        <!--/ End Single Skill -->
                                    </div>
                                    <div class="col-lg-4 col-md-4 col-12 wow zoomIn" data-wow-delay="1s">
                                        <!-- Single Skill -->
                                        <div class="single-skill">
                                            <div class="circle" data-value="0.<?php echo e($exhibition_event_count); ?>" data-size="130">
                                                <strong><?php echo e($exhibition_event_count); ?> +</strong>
                                            </div>
                                            <h4>Exhibition Events</h4>
                                        </div>
                                        <!--/ End Single Skill -->
                                    </div>
                                    <div class="col-lg-4 col-md-4 col-12 wow zoomIn" data-wow-delay="1.2s">
                                        <!-- Single Skill -->
                                        <div class="single-skill">
                                            <div class="circle" data-value="0.<?php echo e($field_event_count); ?>" data-size="130">
                                                <strong><?php echo e($field_event_count); ?>+</strong>
                                            </div>
                                            <h4>Field Events</h4>
                                        </div>
                                        <!--/ End Single Skill -->
                                    </div>
                                </div>
                            </div>
                            <!--/ End Skill Main -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/ End Enroll -->

    <!-- Courses -->
    <section class="courses section-bg section">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-title">
                        <h2>Your <span>Photo</span> Gallery</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="course-slider">
                        <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                            <a class="single-course" href="<?php echo e(asset($item->image)); ?>" data-lightbox="album" data-title="<?php echo e($item->title); ?>" data-alt="not">
                                <div class="course-head overlay">
                                    <img src="<?php echo e(asset($item->image)); ?>" alt="#">

                                </div>

                            </a>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/ End Courses -->

    <!-- Call To Action -->
    <section class="cta" data-stellar-background-ratio="0.5">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 offset-lg-6 col-12">
                    <div class="cta-inner overlay">
                        <div class="text-content">
                            <h2>We Focus On Your Events, News, Memberships.</h2>
                            <p>If you want to join your event or get membership then, simply register and access your area.</p>

                            <div class="button">
                                <a class="btn primary" href="<?php echo e(route('member.register.form')); ?>" >Register Now</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/ End Call To Action -->

    <!-- Team -->
    <section class="team section">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-title">
                        <h2>Our Awesome <span>Members</span></h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-md-6 col-12">
                    <div class="single-team">
                        <img src="<?php echo e(asset($member->profile_image)); ?>" alt="#">
                        <div class="team-hover">
                            <h4><?php echo e($member->first_name.' '.$member->middle_name.' '.$member->last_name); ?><span><?php echo e($member->designation); ?></span></h4>
                            <p><?php echo e($member->memberType->name); ?></p>

                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </section>
    <!--/ End Team -->

    <!-- Testimonials -->
    <section class="testimonials overlay section" data-stellar-background-ratio="0.5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="testimonial-slider">
                        <!-- Single Testimonial -->
                        <div class="single-testimonial">
                            <img src="<?php echo e(asset('assets/frontend/images/testimonial1.jpg')); ?>" alt="#">
                            <div class="main-content">
                                <h4 class="name">Sanavce Faglane</h4>
                                <p>Nulla cursus a metus vel placerat. Fusce malesuada volutpat pretium. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus velit libero, viverra quis euismod vel pellentesque at tortor. Donec</p>
                            </div>
                        </div>
                        <!--/ End Single Testimonial -->
                        <!-- Single Testimonial -->
                        <div class="single-testimonial">
                            <img src="<?php echo e(asset('assets/frontend/images/testimonial2.jpg')); ?>" alt="#">
                            <div class="main-content">
                                <h4 class="name">Jansan Kate</h4>
                                <p>Nulla cursus a metus vel placerat. Fusce malesuada volutpat pretium. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus velit libero, viverra quis euismod vel pellentesque at tortor. Donec</p>
                            </div>
                        </div>
                        <!--/ End Single Testimonial -->
                        <!-- Single Testimonial -->
                        <div class="single-testimonial">
                            <img src="<?php echo e(asset('assets/frontend/images/testimonial3.jpg')); ?>" alt="#">
                            <div class="main-content">
                                <h4 class="name">Sanavce Faglane</h4>
                                <p>Nulla cursus a metus vel placerat. Fusce malesuada volutpat pretium. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus velit libero, viverra quis euismod vel pellentesque at tortor. Donec</p>
                            </div>
                        </div>
                        <!--/ End Single Testimonial -->
                        <!-- Single Testimonial -->
                        <div class="single-testimonial">
                            <img src="<?php echo e(asset('assets/frontend/images/testimonial4.jpg')); ?>" alt="#">
                            <div class="main-content">
                                <h4 class="name">Jansan Kate</h4>
                                <p>Nulla cursus a metus vel placerat. Fusce malesuada volutpat pretium. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus velit libero, viverra quis euismod vel pellentesque at tortor. Donec</p>
                            </div>
                        </div>
                        <!--/ End Single Testimonial -->
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/ End Testimonials -->

    <!-- Events -->
    <section class="events section">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-title">
                        <h2>Upcoming <span>Events</span></h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="event-slider">
                       <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="single-event">
                            <div class="head overlay">
                                <img src="<?php echo e(asset($event->images[0]->image)); ?>" alt="#">
                                <a href="<?php echo e(asset($event->images[0]->image)); ?>" data-fancybox="photo" class="btn"><i class="fa fa-search"></i></a>
                            </div>
                            <div class="event-content">
                                <div class="meta">
                                    Start Date
                                    <span><i class="fa fa-calendar"></i><?php echo e(date('d M Y',strtotime($event->start_date))); ?></span>
                                    <span><i class="fa fa-clock-o"></i><?php echo e(date('h:m A',strtotime($event->start_date))); ?></span><br>
                                    End Date
                                    <span><i class="fa fa-calendar"></i><?php echo e(date('d M Y',strtotime($event->end_date))); ?></span>
                                    <span><i class="fa fa-clock-o"></i><?php echo e(date('h:m A',strtotime($event->end_date))); ?></span>
                                </div>
                                <h4><a href="<?php echo e(route('event.details',$event->id)); ?>"><?php echo e($event->name); ?></a></h4>
                                <p><?php echo e(\Illuminate\Support\Str::limit($event->description, 100, $end='...')); ?></p>
                                <div class="button">
                                    <a href="<?php echo e(route('event.details',$event->id)); ?>" class="btn">Read More</a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/ End Events -->

    <!-- Fun Facts -->
    <div class="fun-facts overlay" data-stellar-background-ratio="0.5">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6 col-6">
                    <!-- Single Fact -->
                    <div class="single-fact">
                        <i class="fa fa-user-o"></i>
                        <div class="number"><span class="counter"><?php echo e($foundry_member_count); ?></span></div>
                        <p>Foundry Members</p>
                    </div>
                    <!--/ End Single Fact -->
                </div>
                <div class="col-lg-3 col-md-6 col-6">
                    <!-- Single Fact -->
                    <div class="single-fact">
                        <i class="fa fa-user-o"></i>
                        <div class="number"><span class="counter"><?php echo e($current_member_count); ?></span></div>
                        <p>Current Members</p>
                    </div>
                    <!--/ End Single Fact -->
                </div>
                <div class="col-lg-3 col-md-6 col-6">
                    <!-- Single Fact -->
                    <div class="single-fact">
                        <i class="fa fa-user-o"></i>
                        <div class="number"><span class="counter"><?php echo e($student_member_count); ?></span></div>
                        <p>Student Members</p>
                    </div>
                    <!--/ End Single Fact -->
                </div>
                <div class="col-lg-3 col-md-6 col-6">
                    <!-- Single Fact -->
                    <div class="single-fact">
                        <i class="fa fa-user-o"></i>
                        <div class="number"><span class="counter"><?php echo e($new_member_count); ?></span></div>
                        <p>New Members</p>
                    </div>
                    <!--/ End Single Fact -->
                </div>
            </div>
        </div>
    </div>
    <!--/ End Fun Facts -->

    <!-- News -->
    <section class="blog section">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-title">
                        <h2>Latest <span>News</span></h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="blog-slider">
                        <!-- Single Blog -->
                        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="single-blog">
                            <div class="blog-head overlay">
                                <div class="date">
                                    <h4><?php echo e(date('d',strtotime($item->upload_date))); ?><span><?php echo e(date('M',strtotime($item->upload_date))); ?></span></h4>
                                </div>
                                <img src="<?php echo e(asset($item->image_or_file)); ?>" alt="#">
                            </div>
                            <div class="blog-content">
                                <h4 class="blog-title"><a href="<?php echo e(route('news.details',$item->id)); ?>"><?php echo e($item->title); ?></a></h4>
                                <div class="blog-info">
                                    <a href="#"><i class="fa fa-user"></i>By: <?php echo e($item->userName->name); ?></a>
                                </div>
                                <p><?php echo e(\Illuminate\Support\Str::limit($item->description, 100, $end='...')); ?></p>
                                <div class="button">
                                    <a href="<?php echo e(route('news.details',$item->id)); ?>" class="btn">Read More<i class="fa fa-angle-double-right"></i></a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <!-- End Single Blog -->

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/ End News -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('additionalJS'); ?>
    <script src="<?php echo e(asset('assets/frontend/lightbox2/js/lightbox.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHP-7.4.2\htdocs\ju\resources\views/frontend/home.blade.php ENDPATH**/ ?>